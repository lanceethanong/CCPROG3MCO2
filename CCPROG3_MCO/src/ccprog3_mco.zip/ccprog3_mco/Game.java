
package ccprog3_mco;
import java.util.*; 

    public class Game {
        private Player player1;
        private Player player2;
        private Board board;
        private Scanner scanner;
        private String name1,name2;
        private int currentPlayer;
        
    }