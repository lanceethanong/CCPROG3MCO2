package ccprog3_mco;

public interface Hopper 
{
	
}
